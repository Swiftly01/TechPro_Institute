
<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Application :: Form
   <?php $__env->endSlot(); ?>
  
  <div   class="container">
    <div  class="row main">
      <div class="col">
        <!-- <h1  class="text-danger home">Home/Services</h1> -->
        <h1 ><a class=" text-danger home" href="<?php echo e(url('/')); ?>">Home/</a><a class=" text-danger home" href="">Application</a><a class=" text-danger home" href="">/outstanding payment</a></h1>
      </div>

      <div class="mb-3">
      <form action="<?php echo e(route('applicant.details')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="app_no" class="form-label mt-2 label-name">View Application Details</label>
        <input style="width: 50%"  type="text" class="form-control" value="<?php echo e(old('lastname')); ?>" name="app_no" placeholder="App/2024/123456" required>
        <span class="text-danger">
          <?php $__errorArgs = ['app_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

            
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
        <button type="submit" class="complete-btn mt-3">Submit</button>
      </form>
      </div>
    </div>
   </div> 
   <div class="container mt-5">
    <div style="background-color: whitesmoke;" class="row">
      <div class="col-lg-6 col-md-12">
        <div class="container">
          <div class="row">
            <div class="col text-center mt-5">
              <?php if(session('error')): ?>
              <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

              </div>
            
              <?php endif; ?> 
      
              <?php if(session('success')): ?>
              <div class="alert alert-success">
                <?php echo e(session('success')); ?>

              </div>   
              <?php endif; ?>
              <h1 class="payment-text">Payment Details</h1>
              <p class="fs-4">Your Payment reference no <span class="text-danger fs-4">Kabirakinola234567FTD</span></p>
              <p class="fs-5">Make direct payment to the below bank details</p>
              <p class="fs-5">Bank Name: UBA</p>
              <p class="fs-5">Account Number: 1025989215</p>
              <p class="fs-5">Account Name: Tech-Pro Edutech</p>
              <p class="fs-5">Upload Payment Evidence</p>
            
              <form action="<?php echo e(route('outstanding.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                      <div class="mb-3">
                        <label for="app_no" class="form-label mt-2 label-name">Aplication Number</label>
                        <input style="width: 50%"  type="text" class="form-control mx-auto " value="<?php echo e(old('lastname')); ?>" name="app_no" placeholder="Doe" required>
                        <span class="text-danger">
                          <?php $__errorArgs = ['app_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <?php echo e($message); ?>

                            
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                      </div>
                      <div class="col text-center">
                        <div class="mb-3">
                          <label for="receipt_url" class="form-label label-name">Upload Payment Receipts</label>
                          <input style="width: 50%;" type="file" class="form-control mt-2 mx-auto" name="receipt_url" required>
                          <span class="text-danger">
                            <?php $__errorArgs = ['receipt_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                              
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </span>
                        </div>

                      </div>
                </div>
          
                <div class="row">
                  <div class="col mx-auto mt-4">
                    <button type="submit" class="complete-btn">Upload</button>
                  </div>
                </div>
            </form>
            </div>
          </div>
        </div>
  
     
  
  
      </div>
      <div class="col-lg-6 col-md-12 p-0">
        <img width="100%" height="100%"  src="<?php echo e(asset('assets/images/IMG_2590.DNG')); ?>" class="" alt="">
  
      </div>
    </div>
   </div>
   
  
  
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/application/outstanding.blade.php ENDPATH**/ ?>