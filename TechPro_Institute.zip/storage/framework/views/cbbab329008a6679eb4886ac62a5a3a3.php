<form action="<?php echo e(route('payment.approval')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="modal fade" id="basicModalapprove<?php echo e($payment->id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Approve :: Payment</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <input type="number" class="form-control  ms-5" value="<?php echo e($payment->id); ?>" name="payment_id" hidden> 
              <div class="mb-3">
                <label for="amount" class="form-label  label-name">Amount</label>
                <input type="number" class="form-control  ms-5" value="<?php echo e(old('amount')); ?>" name="amount" required> 
                <span class="text-danger">
                  <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
              
             </div>
             <div class="mb-3">
              <label for="reference" class="form-label  label-name">Payment Refrence</label>
              <input type="text" class="form-control" value="<?php echo e(old('reference')); ?>" name="reference" required>
              <span class="text-danger">
                <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                  
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
              </span> 
            
           </div>
              
            </div>
            
          
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Approve</button>
            </div>
        </div>
    </div>
</div>

</form><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/payments/approval.blade.php ENDPATH**/ ?>