<?php if (isset($component)) { $__componentOriginal59fca5adad3f44c17f9847442ff25a5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c = $attributes; } ?>
<?php $component = App\View\Components\AdminLayouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayouts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    View :: Students
   <?php $__env->endSlot(); ?>

  <div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Hi, welcome back!</h4>
                <span class="ml-1 fs-5"><?php echo e($user->email); ?></span>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Table</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Datatable</a></li>
            </ol>
        </div>
    </div>
     <?php if(session('success')): ?>
     <div class="alert alert-primary">

        <?php echo e(session('success')); ?>


     </div>
        
     <?php endif; ?>

     <?php if(session('error')): ?>
     <div class="alert alert-danger">

        <?php echo e(session('error')); ?>


     </div>
        
     <?php endif; ?>


    <div class="col-12">
      <div class="card">
          <div class="card-header">
              <h4 class="card-title">Basic Datatable</h4>
          </div>
          <div class="card-body">
              <div class="table-responsive">
                  <table id="example" class="display" style="min-width: 845px">
                      <thead>
                          <tr>
                              <th>#</th>
                              <th>Firstname</th>
                              <th>Lastname</th>
                              <th>Email</th>
                              <th>App No</th>
                              <th>Course</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tbody>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($student->firstname); ?></td>
                            <td><?php echo e($student->lastname); ?></td>
                            <td><?php echo e($student->email); ?></td>
                            <td><?php echo e($student->app_no); ?></td>
                            <td><?php echo e($student->course->name); ?></td>
                            <td>
                                <div style="display: flex;gap:5px">
                                <button class="btn btn-primary" data-toggle="modal" data-target="#basicModal<?php echo e($student->id); ?>" >Edit</button>
                                <?php echo $__env->make('admin.students.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                                <?php echo $__env->make('admin.students.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <button class="btn btn-danger"  data-toggle="modal" data-target="#basicModaldelete<?php echo e($student->id); ?>" >Delete</button>

                                </div>
                                
                              

                            </td>
                        </tr>
                        
                    </tbody>
                        
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                      <tfoot>
                          <tr>
                              <th>#</th>
                              <th>Firstname</th>
                              <th>Lastname</th>
                              <th>Email</th>
                              <th>App No</th>
                              <th>Course</th>
                              <th>action</th>
                          </tr>
                      </tfoot>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>

  




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $attributes = $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $component = $__componentOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/students/view.blade.php ENDPATH**/ ?>