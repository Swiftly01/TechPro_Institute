<form action="<?php echo e(route('application.approve')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="modal fade" id="basicModalApprove<?php echo e($student->id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Application :: Approval</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">Are you sure you want to approve <?php echo e(ucfirst(strtolower($student->firstname))); ?> <?php echo e(ucfirst(strtolower($student->lastname))); ?></div>
            <input type="hidden"  name="student_id" type="text" value="<?php echo e($student->id); ?>">
            <span class="text-danger">
              <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

                
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success">Approve</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                
            </div>
        </div>
    </div>
</div>

</form><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/students/approveModal.blade.php ENDPATH**/ ?>