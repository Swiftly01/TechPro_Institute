<?php if (isset($component)) { $__componentOriginal59fca5adad3f44c17f9847442ff25a5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c = $attributes; } ?>
<?php $component = App\View\Components\AdminLayouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayouts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Payments
   <?php $__env->endSlot(); ?>

  <div class="container-fluid">
    <div class="row page-titles mx-0">
      <div class="col-sm-6 p-md-0">
          <div class="welcome-text">
              <h4>Hi, welcome back!</h4>
              <span class="ml-1 fs-5"><?php echo e($user->email); ?></span>
          </div>
      </div>
      <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="javascript:void(0)">Payments</a></li>
              <li class="breadcrumb-item active"><a href="javascript:void(0)">Datatable</a></li>
          </ol>
      </div>
  </div>

  <?php if(session('success')): ?>
     <div class="alert alert-primary">

        <?php echo e(session('success')); ?>


     </div>
        
     <?php endif; ?>

     <?php if(session('error')): ?>
     <div class="alert alert-danger">

        <?php echo e(session('error')); ?>


     </div>
        
     <?php endif; ?>


  <div class="col-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Basic Datatable</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="example" class="display" style="min-width: 845px">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Firstname</th>
                            <th>Lastname</th>
                            <th>App No</th>
                            <th>Amount_due</th>
                            <th>purpose</th>
                            <th>Receipt</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                          <td><?php echo e($index + 1); ?></td>
                          <td><?php echo e($payment->student->firstname); ?></td>
                          <td><?php echo e($payment->student->lastname); ?></td>
                          <td><?php echo e($payment->student->app_no); ?></td>
                          <td><?php echo e($payment->amount_due); ?></td>
                          <td><?php echo e($payment->purpose); ?></td>
                          <td> <a href="<?php echo e(asset('upload/'.$payment->receipt_url)); ?>" target="_blank">
                            <img style="height: 100px" src="<?php echo e(asset('upload/'.$payment->receipt_url)); ?>" alt="">
                          </a></td>
                          <td>
                            <?php echo $__env->make('admin.payments.approval', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <div style="display: flex;gap:5px">
                              <a href="<?php echo e(route('details.show',['id' => $payment->id])); ?>" class="btn btn-primary" >View Details</a>
                              
                              <button class="btn btn-success"data-toggle="modal" data-target="#basicModalapprove<?php echo e($payment->id); ?>" >Approve</button>
                              </div>
                              
                            

                          </td>
                      </tr>
                      
                  </tbody>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <tfoot>
                        <tr>
                          <th>#</th>
                          <th>Firstname</th>
                          <th>Lastname</th>
                          <th>App No</th>
                          <th>Amount_due</th>
                          <th>purpose</th>
                          <th>Receipt</th>
                          <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>


  </div>

   


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $attributes = $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $component = $__componentOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/payments/view.blade.php ENDPATH**/ ?>