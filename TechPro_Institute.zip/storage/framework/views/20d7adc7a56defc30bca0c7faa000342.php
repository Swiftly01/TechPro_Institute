<?php if (isset($component)) { $__componentOriginal59fca5adad3f44c17f9847442ff25a5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c = $attributes; } ?>
<?php $component = App\View\Components\AdminLayouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayouts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Student :: Details
   <?php $__env->endSlot(); ?>

  <div class="container-fluid">
    <div class="row page-titles mx-0">
      <div class="col-sm-6 p-md-0">
          <div class="welcome-text">
              <h4>Hi, welcome back!</h4>
              <span class="ml-1 fs-5"><?php echo e($user->email); ?></span>
          </div>
      </div>
      <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="javascript:void(0)">Payments</a></li>
              <li class="breadcrumb-item active"><a href="javascript:void(0)">Datatable</a></li>
          </ol>
      </div>
  </div>


  <div class="col-12">
    <div class="card">
        <div class="card-header ">
            <h4 class="card-title ">Student :: Details</h4>
        </div>
        <div class="card-body">
          <div style="display: flex; justify-content:space-between; align-item:center">
          <div>
            <h4>Firstname : <?php echo e($student->firstname); ?></h4>
            <h4>lastname : <?php echo e($student->lastname); ?></h4>
            <h4>Email Address : <?php echo e($student->email); ?></h4>
            <h4>Phone Number : <?php echo e($student->phone); ?></h4>
            <h4>App No : <?php echo e($student->app_no); ?></h4>
            <h4>Course : <?php echo e($student->course->name); ?></h4>
          </div>
          <div>
            <img style="height: 200px; width:200px" src="<?php echo e(asset('upload/'. $student->image_url)); ?>" alt="">
          </div>
        

          </div>
            
        </div>
    </div>
  </div>
  
  


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $attributes = $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $component = $__componentOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/payments/details.blade.php ENDPATH**/ ?>