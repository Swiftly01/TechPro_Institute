<?php if (isset($component)) { $__componentOriginal59fca5adad3f44c17f9847442ff25a5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c = $attributes; } ?>
<?php $component = App\View\Components\AdminLayouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayouts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    View :: Students
   <?php $__env->endSlot(); ?>

  <div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Hi, welcome back!</h4>
                <span class="ml-1 fs-5"><?php echo e($user->email); ?></span>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Table</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Datatable</a></li>
            </ol>
        </div>
    </div>
     <?php if(session('success')): ?>
     <div class="alert alert-primary">

        <?php echo e(session('success')); ?>


     </div>
        
     <?php endif; ?>

     <?php if(session('error')): ?>
     <div class="alert alert-danger">

        <?php echo e(session('error')); ?>


     </div>
        
     <?php endif; ?>


    <div class="col-12">
      <div class="card">
          <div class="card-header">
              <h4 class="card-title">Basic Datatable</h4>
          </div>
          <div class="card-body">
            <!-- Nav tabs -->
            <div class="default-tab">
              <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                      <a class="nav-link active" data-toggle="tab" href="#home">Pending</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#profile">Approved</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#contact">Rejected</a>
                  </li>
                  
              </ul>
              <div class="tab-content">
                  <div class="tab-pane fade show active" id="home" role="tabpanel">
                      <div class="pt-4">
                        <div class="table-responsive">
                            <table class="table  table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th  scope="col">Firstname</th>
                                        <th scope="col" >Lastname</th>
                                        <th  scope="col">Email</th>
                                        <th  scope="col">Course</th>
                                        <th  scope="col">View Details</th>
                                        <th  scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pendingStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tbody>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($student->firstname); ?></td>
                                    <td><?php echo e($student->lastname); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td><?php echo e($student->course->name); ?></td>
                                    <td><a href="<?php echo e(route('details.show',['id' => $student->id])); ?>">View details</a></td>
                                    <td>
                                        <div style="display: flex;gap:2px">
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#basicModalApprove<?php echo e($student->id); ?>" >Approve</button>
                                        <?php echo $__env->make('admin.students.approveModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                        <?php echo $__env->make('admin.students.rejectModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <button class="btn btn-danger"  data-toggle="modal" data-target="#basicModalReject<?php echo e($student->id); ?>" >Reject</button>
                                        </div>
    
                                    </td>
                                </tr>
                                
                            </tbody>
                                
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                         
                      </div>
                          
                      </div>
                  </div>
                  <div class="tab-pane fade" id="profile">
                      <div class="pt-4">
                        <table id="example" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Email</th>
                                    <th>Course</th>
                                    <th>View Details</th>
                                
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $approvedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                              <tr>
                                  <td><?php echo e($index + 1); ?></td>
                                  <td><?php echo e($student->firstname); ?></td>
                                  <td><?php echo e($student->lastname); ?></td>
                                  <td><?php echo e($student->email); ?></td>
                                  <td><?php echo e($student->course->name); ?></td>
                                  <td><a href="<?php echo e(route('details.show',['id' => $student->id])); ?>">View details</a></td>
                                  
                              </tr>
                              
                          </tbody>
                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Email</th>
                                    <th>Course</th>
                                    <th>View Details</th>
                                
                                </tr>
                            </tfoot>
                        </table>
                        
                          
                      </div>
                  </div>
                  <div class="tab-pane fade" id="contact">
                      <div class="pt-4">
                        <div class="table-responsive">
                            <table class="table  table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th  scope="col">Firstname</th>
                                        <th scope="col" >Lastname</th>
                                        <th  scope="col">Email</th>
                                        <th  scope="col">Course</th>
                                        <th  scope="col">View Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $rejectedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tbody>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($student->firstname); ?></td>
                                    <td><?php echo e($student->lastname); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td><?php echo e($student->course->name); ?></td>
                                    <td><a href="<?php echo e(route('details.show',['id' => $student->id])); ?>">View details</a></td>
                                    
                                </tr>
                                
                            </tbody>
                                
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                         
                      </div>
                          
                      </div>
                  </div>
              </div>
          </div>
              
          </div>
      </div>
  </div>
</div>

  

 




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $attributes = $__attributesOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__attributesOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c)): ?>
<?php $component = $__componentOriginal59fca5adad3f44c17f9847442ff25a5c; ?>
<?php unset($__componentOriginal59fca5adad3f44c17f9847442ff25a5c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/students/approve.blade.php ENDPATH**/ ?>