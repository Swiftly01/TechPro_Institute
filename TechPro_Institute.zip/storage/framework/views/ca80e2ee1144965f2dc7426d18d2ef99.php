
<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    Student :: Details
   <?php $__env->endSlot(); ?>
  
  <div class="container">
    <div class="row main">
      <div class="col">
        <h1>
          <a class="text-danger home" href="<?php echo e(url('/')); ?>">Home</a> / 
          <a class="text-danger home" href="">Application</a> / 
          <a class="text-danger home" href="">Details</a>
        </h1>
      </div> 
    </div>
  </div> 

  <!-- Student Details -->
  <div class="container mt-5">
    <div class="card">
      <div class="card-header" style="background-color: #0A5098;">
        <h4 class="card-title text-white">Student :: Details</h4>
      </div>
      <div class="card-body">
        <div class="row">
          <!-- Student Information -->
          <div class="col-md-8">
            <h4>Firstname: <?php echo e($student->firstname); ?></h4>
            <h4>Lastname: <?php echo e($student->lastname); ?></h4>
            <h4>Email Address: <?php echo e($student->email); ?></h4>
            <h4>Phone Number: <?php echo e($student->phone); ?></h4>
            <h4>App No: <?php echo e($student->app_no); ?></h4>
            <h4>Course: <?php echo e($student->course->name); ?></h4>
          </div>

          <!-- Student Image -->
          <div class="col-md-4 mt-3 mt-md-0 d-flex justify-content-md-end">
            <img class="img-fluid" style="max-height: 200px; width: 200px;" src="<?php echo e(asset('upload/' . $student->image_url)); ?>" alt="Student Image">
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Payment Details -->
<?php if(isset($payments) && $payments): ?>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header" style="background-color: #0A5098;">
        <h4 class="card-title text-white">Payment :: Details</h4>
      </div>
      <div class="card-body">
        <!-- Responsive Table Wrapper -->
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Date</th>
                <th scope="col">Description</th>
                <th scope="col">Payment Reference</th>
                <th scope="col">Receipt</th>
                <th scope="col">Amount</th>
              </tr>
            </thead>
            <tbody>
              <?php $totalAmount = 0 ?>
              <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                  <th scope="row"><?php echo e($index + 1); ?></th>
                  <td><?php echo e(date('d/m/y', strtotime($payment->created_at))); ?></td>
                  <td><?php echo e($payment->schedule->desc); ?></td>
                  <td><?php echo e($payment->payment_reference); ?></td>
                  <td>
                    <a href="<?php echo e(asset('upload/' . $payment->receipt_url)); ?>" target="_blank">
                      <img class="img-fluid" style="height: 100px;" src="<?php echo e(asset('upload/' . $payment->receipt_url)); ?>" alt="">
                    </a>
                  </td>
                  <td>&#8358;<?php echo e(number_format($payment->amount)); ?></td>
                </tr>
                <?php $totalAmount += $payment->amount; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td colspan="5" class="text-right"><strong>Total Amount Paid</strong></td>
                <td><strong>&#8358;<?php echo e(number_format($totalAmount)); ?></strong></td>
              </tr>
              <?php if( isset($balanceDue) && $balanceDue > 0): ?>
                <tr>
                  <td colspan="5" class="text-right"><strong>Balance Remaining</strong></td>
                  <td><strong>&#8358;<?php echo e(number_format($balanceDue)); ?></strong></td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>



   
   </div>
   
  
  
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/students/details.blade.php ENDPATH**/ ?>