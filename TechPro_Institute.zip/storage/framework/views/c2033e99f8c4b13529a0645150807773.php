<form action="<?php echo e(route('student.edit', ['id' => $student->id])); ?>" enctype="multipart/form-data" method="POST">
  <?php echo csrf_field(); ?>
  <div class="modal fade" id="basicModal<?php echo e($student->id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit :: Student</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label for="firstName" class="form-label mt-2 ms-5 label-name">FirstName</label>
                <input type="text" class="form-control  ms-5" value="<?php echo e($student->firstname); ?>" name="firstname" required> 
                <span class="text-danger">
                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                        
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
               </span> 
             </div>
             <div class="mb-3">
              <label for="lastName" class="form-label mt-2 ms-5 label-name">LastName</label>
              <input  type="text" class="form-control  ms-5" value="<?php echo e($student->lastname); ?>" name="lastname" required>
              <span class="text-danger">
                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
           </span>  
             </div>
             <div class="mb-3">
              <label for="email" class="form-label mt-2 ms-5 label-name">Email</label>
              <input  type="email" class="form-control ms-5" value="<?php echo e($student->email); ?>" name="email" required>
              <span class="text-danger">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
           </span>    
             </div>
             <div class="mb-3">
              <label for="phone" class="form-label mt-2 ms-5 label-name">Phone No</label>
              <input  type="number" class="form-control ms-5" value="<?php echo e($student->phone); ?>" name="phone" required> 
              <span class="text-danger">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
           </span>  
             </div>
             <div class="mb-3">
              <label for="phone" class="form-label mt-2 label-name">Upload Pitch Deck</label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Upload</span>
                </div>
                <div class="custom-file">
                    <input name="image_url" type="file" class="custom-file-input">
                    <label class="custom-file-label">Choose file</label>
                </div>
              </div>
              <span class="text-danger">
                <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
           </span> 
              
             </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>
</form><?php /**PATH C:\laragon\www\__tech_pro\TechPro_Institute\resources\views/admin/students/edit.blade.php ENDPATH**/ ?>