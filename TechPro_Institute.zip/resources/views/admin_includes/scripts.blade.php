  <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="{{ asset('admin-assets/vendor/global/global.min.js') }}"></script>
    <script src="{{ asset('admin-assets/js/quixnav-init.js') }}"></script>
    <script src="{{ asset('admin-assets/js/custom.min.js') }}"></script>


    <script src="{{ asset('admin-assets/vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('admin-assets/js/plugins-init/datatables.init.js') }}"></script>

    


    <!-- Vectormap -->  
    <script src="{{ asset('admin-assets/vendor/raphael/raphael.min.js') }}"></script>
    <script src="{{ asset('admin-assets/vendor/morris/morris.min.js') }}"></script>


    <script src="{{ asset('admin-assets/vendor/circle-progress/circle-progress.min.js') }}"></script>
    <script src="{{ asset('admin-assets/vendor/chart.js/Chart.bundle.min.js') }}"></script>

    <script src="{{ asset('admin-assets/vendor/gaugeJS/dist/gauge.min.js') }}"></script>

    <!--  flot-chart js -->
    <script src="{{ asset('admin-assets/vendor/flot/jquery.flot.js') }}"></script>
    <script src="{{ asset('admin-assets/vendor/flot/jquery.flot.resize.js') }}"></script>

    <!-- Owl Carousel -->
    <script src="{{ asset('admin-assets/vendor/owl-carousel/js/owl.carousel.min.js') }}"></script>

    <!-- Counter Up -->
    <script src="{{ asset('admin-assets/vendor/jqvmap/js/jquery.vmap.min.js') }}"></script>
    <script src="{{ asset('admin-assets/vendor/jqvmap/js/jquery.vmap.usa.js') }}"></script>
    <script src="{{ asset('/admin-assets/vendor/jquery.counterup/jquery.counterup.min.js') }}"></script>


    <script src="{{ asset('admin-assets/js/dashboard/dashboard-1.js') }}"></script>