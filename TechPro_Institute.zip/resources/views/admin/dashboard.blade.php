<x-admin-layouts>
  <x-slot:title>
    Dashboard
  </x-slot:title>

   test


</x-admin-layouts>